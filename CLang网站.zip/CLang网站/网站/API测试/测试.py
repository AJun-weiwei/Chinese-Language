import requests
run = requests.post(
  'https://debatable-unhelpful-suffrage.ngrok-free.dev/api/user',
  json={'CodeData':{'1.txt':['导入 2.txt\n','打印（12）'],'2.txt':['打印（11）']},'MainFile':'1.txt'}
)
print([run.json()[i] for i in run.json()])
