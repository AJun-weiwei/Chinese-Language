import pygame
import sys
import random
pygame.init()
n2 = n3,n4 = 900,600
n1 = pygame.display.set_mode(n2)
n5 = pygame.image.load('C:\我的文件夹\编程文件夹\自定义解释器\解释器\游戏\游戏1\images\小人.png')
n7 = pygame.image.load('C:\我的文件夹\编程文件夹\自定义解释器\解释器\游戏\游戏1\images\背景.png')
n6 = (0,0)
while True:
    for i in pygame.event.get():
        if i.type==pygame.QUIT:
            sys.exit()
        if i.type==pygame.MOUSEBUTTONDOWN:
            n6 = (random.randint(0,900),random.randint(0,600))
    n1.blit(n7, (0,0))
    n1.blit(n5,n6)
    pygame.display.flip()
pygame.quit()