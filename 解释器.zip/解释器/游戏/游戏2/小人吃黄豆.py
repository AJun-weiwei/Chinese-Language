import pygame
import random
pygame.init()
n2 = n3,n4 = 900,600
n1 = pygame.display.set_mode(n2)
n5 = pygame.image.load('D:\我的文件夹\编程文件夹\自定义解释器\解释器\游戏\游戏2\images\小人.png')
n6 = pygame.image.load('D:\我的文件夹\编程文件夹\自定义解释器\解释器\游戏\游戏2\images\背景.png')
n9 = pygame.image.load('D:\我的文件夹\编程文件夹\自定义解释器\解释器\游戏\游戏2\images\黄豆(1).png')
n13 = pygame.font.Font(None,36)
pygame.display.update()
n7 = (0,0)
n8 = (450,300)
n5_rect = pygame.Rect(0,0,100,100)
n9_rect = pygame.Rect(450,300,150,100)
n12 = 0
num1 = True
while num1:
    for i in pygame.event.get():
        if i.type==pygame.QUIT:
            num1 = False
        if i.type==pygame.KEYDOWN:
            if i.key==pygame.K_LEFT:
                n5_rect.x-=10
            elif i.key==pygame.K_RIGHT:
                n5_rect.x+=10
            elif i.key==pygame.K_UP:
                n5_rect.y-=10
            elif i.key==pygame.K_DOWN:
                n5_rect.y+=10
    n1.blit(n6,(0,0))
    n1.blit(n5,n5_rect)
    n1.blit(n9,n9_rect)
    if n5_rect.colliderect(n9_rect):
        n12+=1
        n9_rect.x = random.randint(0,900)
        n9_rect.y = random.randint(0,600)
    n14 = n13.render(str(n12),True,(0,0,255))
    n1.blit(n14,(850,50))
    pygame.display.flip()
pygame.quit()