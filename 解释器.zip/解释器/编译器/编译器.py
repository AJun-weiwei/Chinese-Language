import os
while True:
    x1 = input('>>>')
    with open(x1,'r',encoding='utf-8') as n1:
        l2 = ['<html>','<head>','   <meta charset="utf-8">','</head>','<body>','    <script>']
        l1 = n1.readlines()
        if len(l1)!=1:
            l3 = []
            for i in l1:
                l3.append(i.split('\n')[0])
            l1 = l3
        num1 = 0
        num2 = '0'
        for j in l1:
            num1+=1
            if '显示（' in j and '）' in j:
                n2 = j.replace('显示（','_')
                n3 = n2.replace('）','_')
                n4 = n3.split('_')
                try:
                    int(n4[1])
                except:
                    if '‘' in n4[1] and '’' in n4[1]:
                        n5 = n4[1].replace('’','\'')
                        n6 = n5.replace('‘', '\'')
                        l2.append(f'        document.write({n6})')
                    else:
                        print(f'''第{num1}行 编译错误
{n4[1]}未定义''')
                        num2 = '1'
                        break
                else:
                    l2.append(f'        document.write({n4[1]})')
            else:
                print(f'''第{num1}行 编译错误
{j}未定义''')
                num2 = '1'
                break
        l2.append('    </script>')
        l2.append('</body>')
        l2.append('</html>')
        if num2=='0':
            n7 = x1.replace('.txt','.html')
            with open(n7,'w',encoding='utf-8') as n8:
                for k in l2:
                    n8.write(k+'\n')
            os.system(f'start {n7}')