while True:
    n1 = input('>>>')
    n2 = 'print(' + n1 + ')'
    try:
        exec(n1)
    except Exception as n3:
        print(f'错误：{n3}')
    else:
        exec(n2)