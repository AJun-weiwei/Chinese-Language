#include<iostream>
#include<Windows.h>
#include<string>
using namespace std;
int main(){
	string n1;
	while (n1!="exit"){
		cin>>n1;
		if (n1=="1"){
			Beep(523,200);
		}
		else if (n1=="2"){
			Beep(578,200);
		}
		else if (n1=="3"){
			Beep(659,200);
		}
		else if (n1=="4"){
			Beep(698,200);
		}
		else if (n1=="5"){
			Beep(784,200);
		}
		else if (n1=="6"){
			Beep(880,200);
		}
		else if (n1=="7"){
			Beep(988,200);
		}
		else {
			cout<<"��"<<endl;
		}
		Sleep(500);
	}
	return 0;
} 
