#include<fstream>
#include<iostream>
#include<string>
using namespace std;
int main(){
	string n1,l1[1000];
	fstream n2;
	while (true){
		cout<<">>>"
		cin>>n1;
		n2.open(n1,ios::in | ios::out);
		n2>>d1;
		cout<<d1<<endl;
	}
	return 0;
}
