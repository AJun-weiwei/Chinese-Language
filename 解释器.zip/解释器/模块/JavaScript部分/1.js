function add(a,b){
    var c = a+b
    return c
}
var d = add(1,2)
console.log(d)