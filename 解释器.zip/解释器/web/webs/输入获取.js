const input1 = document.getElementById("input1");
const input2 = document.getElementById('input2');
const print1 = document.getElementById("print1");
const print2 = document.getElementById('print2');
const print3 = document.getElementById('print3');
const print4 = document.getElementById('print4');
input2.addEventListener("click",function (){
  if (input1.value==='中文编程语言解释器'){
    print1.innerText = '产品名称：中文编程语言解释器\n产品开发者：许骏玮\n产品费用:0$\n产品介绍：基于python的一款以中文为主的解释性编程语言，适合编程初学者。\n产品功能：能运行简单的算法，包括定义函数、定义变量、数学运算、输入、输出等等。\n产品最新版本：1.2.1试验版（最新可下载v1.1.0）\n产品号：cnc01\n普通用户激活码：gnQ6';
    print2.innerText = '使用方法：\n1.运行解释器\n2.登录账户，若还没有账户，请注册一个新账户\n3.输入需要运行的文件的绝对路径，自动运行文件';
    print3.innerText = '操作指令：\n退出（）----关闭解释器\n注册（）----注册新账户\n登录（）----登录账户\n查看账户信息（）----查看当前账户信息\n查看账户列表（）----查看所有账户的信息（需开发者权限）\n退出账户（）----退出当前账户（v1.2.1试验版以下为注销账户（）----退出当前账户）\n获取订阅编码 pro（）----获取编码 pro 激活码（试验版）\n激活订阅编码 pro（）----激活编码 pro 的订阅（试验版）';
    print4.innerText = 'v1.2.1版本更新内容：\n1.本产品现为统一产品，增加了订阅制，普通用户需订阅才能使用高级编码功能\n2.修复了一些表达错误';
  }
  else if (input1.value==='中文网页编程语言编译器'){
    print1.innerText = '产品名称：中文网页编程语言编译器\n产品开发者：许骏玮\n产品费用:0$\n产品介绍：基于python的一款以中文为主的编译性编程语言，适合做网页开发的初学者。\n产品最新版本：1.0.0\n产品号：cnc02';
    print2.innerText = '';
    print3.innerText = '';
  }
  else if (input1.value==='中文编程语言解释器IDE') {
    print1.innerText = '产品名称：中文编程语言解释器IDE\n产品开发者：许骏玮\n产品费用:0$\n产品介绍：一款基于C++为中文编程语言解释器开发的IDE。\n产品最新版本：1.0.0测试版\n产品号：cnc03';
    print2.innerText = '';
    print3.innerText = '';
  }
  else if (input1.value==='中文编程语言解释器社区版') {
    print1.innerText = '产品名称：中文编程语言解释器社区版\n产品开发者：许骏玮\n产品费用:0$\n产品介绍：一款基于python的编程语言，适合业余爱好者。\n产品最新版本：1.0.0\n产品号：cnc04';
    print2.innerText = '';
    print3.innerText = '';
  }
  else {
    print1.innerText = '还没有此产品。';
    print2.innerText = '';
    print3.innerText = '';
  }
})
